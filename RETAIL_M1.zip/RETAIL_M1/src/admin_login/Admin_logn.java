package admin_login;

import org.openqa.selenium.WebDriver;

public class Admin_logn{
    
		public static void main(String args[])
		{
	        WebDriver dr = null;
	        String kw,loc,td;
	       
	        Functions1 f1 = new Functions1(dr);
	        Read_excel xcl = new Read_excel();
	        
	     	/*kw= excl.read(0,0);
	     	System.out.println(kw);*/
	     	
	         for(int r=2;r<=8;r++)
	         {
	         	kw=xcl.read1(r, 2);
	         	loc= xcl.read1(r, 3);
	         	td= xcl.read1(r, 4);
	         	
	         	switch(kw)
	         	{
	         	case "launchchrome":
	         		f1.launchChrome(td);
	         		break;
	         	case "enter_txt":
	         		f1.enter_txt(loc, td);
	         		break;
	         	case "click_btn":
	         		f1.clik(loc);
	         		break;
	         	case "verify":
	         		f1.verify(loc,td);
	         		break;
	         	}
	         }
		}
	}


