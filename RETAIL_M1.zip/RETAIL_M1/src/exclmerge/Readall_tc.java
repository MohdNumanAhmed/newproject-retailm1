package exclmerge;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Readall_tc {
	public String read1(int row,int col)
	 {
	  String s = null;
		try
		{
			File f = new File("E:\\Features.xlsx");
			//File f = new File("e:\\1.xlsx");	
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet2");
			XSSFRow r = sh.getRow(row);
			XSSFCell c = r.getCell(col);
			
			s=c.getStringCellValue();
	}
		
				catch(IOException e)
		{
			
		 e.printStackTrace();
		}
		return(s);
	}
}


