package exclmerge;

import org.openqa.selenium.WebDriver;

public class Mainexcel {

	public static void main(String[] args) 
	{
		 String fn,tcid,flag,nos,tcid1,tsid,kw,loc,td;
         
		WebDriver dr=null;
		Readmain_excel ex= new Readmain_excel();
		Readall_tc tc= new Readall_tc();
		Functions f2= new Functions(dr);
		for(int r=2;r<=6;r++)
		{
	      fn= ex.read(r, 0);
	      tcid=ex.read(r,1);
	      flag=ex.read(r,2);
		  nos=ex.read(r,3);
//		  System.out.println(fn);
//		  System.out.println(tcid);
//		  System.out.println(flag);
//		  System.out.println(nos);

		  if(flag.equalsIgnoreCase("y"))
		  {
			
		  System.out.println("flag is yes");
		       operate();
		  }}}
	
		  public void operate()
		  {
		      
			for(int r1=2;r1<=44;r1++)
		{

			tcid1=tc.read1(r1,1);
			tsid=tc.read1(r1,2);
			kw=tc.read1(r1,3);
			loc=tc.read1(r1,4);	
			td = tc.read1(r1,5);
		
			if(tcid.equals(tcid1))
			{  
			switch(kw)
         	{
         	case "launchchrome":
         		f2.launchChrome(td);
         		break;
         	case "enter_txt":
         		f2.enter_txt(loc, td);
         		break;
         	case "click_btn":
         		f2.clik(loc);
         		break;
         	case "check_box":
         		f2.clik(loc);
         	case "click_btn1":
         		f2.clik1(loc);
         		break;
         	case "pop_up":
         		f2.popup();
         		break;
         	case "verify":
         		f2.verify(loc,td);
         		break;
         	}}}}}
		  


