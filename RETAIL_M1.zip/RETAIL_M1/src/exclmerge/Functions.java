package exclmerge;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Functions {
	
	 WebDriver dr2;
		
		Functions(WebDriver dr2)
		{
			this.dr2 = dr2;
		}
		
		public void enter_txt(String xp, String data)
		{
			dr2.findElement(By.xpath(xp)).sendKeys(data);
		}
		public void clik(String xp)
		{
			System.out.println("in clik");
			dr2.findElement(By.xpath(xp)).click();
		}
		public void launchChrome(String url)
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver74.exe");
			dr2 = new ChromeDriver();
			dr2.get(url);
			
		}
		public void clik1(String xp)
		{
			System.out.println("in clik1");
			WebDriverWait wt= new WebDriverWait(dr2,20);
			wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"content\"]/div[1]/div/div/button")));
			dr2.findElement(By.xpath(xp)).click();
		}
		public void popup()
		{
			Alert a = dr2.switchTo().alert();
			a.accept();
		}
		public void verify(String xp,String exp)
		{
		  	String act = dr2.findElement(By.xpath(xp)).getText();
		  	if(act.equalsIgnoreCase(exp))
		  	{
		  		String s1= "pass";
		  	
		  		System.out.println("pass");
		  		
	       }
		  	else
		  	{
		  		String s2="fail";
		  	   
		  		System.out.println("fail");
		  	}
		}

}
