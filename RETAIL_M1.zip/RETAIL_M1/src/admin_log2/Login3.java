package admin_log2;

import org.openqa.selenium.WebDriver;

import admin_log1.Functions2;
import admin_log1.Read_excel1;

public class Login3 {
	public static void main(String args[])
	{
        WebDriver dr = null;
        String kw,loc,td;
     
        Functions3 f3 = new Functions3(dr);
        Read_excel2 xcl = new Read_excel2();
        
     	/*kw= excl.read(0,0);
     	System.out.println(kw);*/
     	
         for(int r=2;r<=11;r++)
         {
         	kw=xcl.read2(r, 2);
         	loc= xcl.read2(r, 3);
         	td= xcl.read2(r, 4);
         
         	switch(kw)
         	{
         	case "launchchrome":
         		f3.launchChrome(td);
         		break;
         	case "enter_txt":
         		f3.enter_txt(loc, td);
         		break;
         	case "enter_val":
         		f3.enter_val(loc,td);
         		break;
         	case "click_btn":
         		f3.clik(loc);
         		break;
         	case "verify":
         		f3.verify(loc,td);
         		break;
         	}
         }
	}
}


