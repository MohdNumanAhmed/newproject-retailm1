package admin_log1;

import org.openqa.selenium.WebDriver;

   public class Login2 {
	   
	public static void main(String args[]) throws InterruptedException
	{
        WebDriver dr = null;
        String kw,loc,td;
       
        Functions2 f2 = new Functions2(dr);
        Read_excel1 xcl = new Read_excel1();
        
     	/*kw= excl.read(0,0);
     	System.out.println(kw);*/
     	
         for(int r=2;r<=11;r++)
         {
         	kw=xcl.read2(r, 2);
         	loc= xcl.read2(r, 3);
         	td= xcl.read2(r, 4);
         	
         	switch(kw)
         	{
         	case "launchchrome":
         		f2.launchChrome(td);
         		break;
         	case "enter_txt":
         		f2.enter_txt(loc, td);
         		break;
         	case "click_btn":
         		f2.clik(loc);
         		break;
         	case "check_box":
         		f2.clik(loc);
         	case "click_btn1":
         		f2.clik1(loc);
         		break;
         	case "pop_up":
         		f2.popup();
         		break;
         	case "verify":
         		f2.verify(loc,td);
         		break;
         		
         	}
         }
	}
}

