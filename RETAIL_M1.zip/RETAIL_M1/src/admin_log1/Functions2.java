package admin_log1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Functions2 {
	 WebDriver dr2;
		
		Functions2(WebDriver dr2)
		{
			this.dr2 = dr2;
		}
		
		public void enter_txt(String xp, String data)
		{
			dr2.findElement(By.xpath(xp)).sendKeys(data);
		}
		public void clik(String xp)
		{
			System.out.println("in clik");
			dr2.findElement(By.xpath(xp)).click();
		}
		public void launchChrome(String url)
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver74.exe");
			dr2 = new ChromeDriver();
			dr2.get(url);
			
		}
		public void clik1(String xp) throws InterruptedException
		{
			System.out.println("in clik1");
			WebDriverWait wt= new WebDriverWait(dr2,20);
			wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"content\"]/div[1]/div/div/button")));
			Thread.sleep(3000);
			dr2.findElement(By.xpath(xp)).click();
		}
		public void popup() throws InterruptedException
		{
			Thread.sleep(3000);
			Alert a = dr2.switchTo().alert();
			a.accept();
		}
		public void verify(String xp,String exp)
		{
		  	String act = dr2.findElement(By.xpath(xp)).getText();
		  	if(act.equalsIgnoreCase(exp))
		  	{
		  		String s1= "pass";
		  		write(11,5,s1);
		  		System.out.println("pass");
		  		
	       }
		  	else
		  	{
		  		String s2="fail";
		  	    write(11,5,s2);
		  		System.out.println("fail");
		  	}
		}
		  	
		
		public void write(int a, int b, String s2)
		{
		try
		{
			File f = new File("E:\\3.xlsx");
			//File f = new File("e:\\1.xlsx");	
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			FileOutputStream fos= new FileOutputStream(f);
			XSSFRow r1 = sh.getRow(a);
			XSSFCell c1  = r1.createCell(b);
			c1.setCellValue(s2);
			wb.write(fos);
	      }

		catch(IOException e)
	 	{

	     e.printStackTrace();
	 	}
	}}
	



