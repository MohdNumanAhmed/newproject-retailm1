package admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_excl
{
	public String read(int row,int col)
	 {
	  String s = null;
		try
		{
			File f = new File("E:\\1.xlsx");
			//File f = new File("e:\\1.xlsx");	
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r = sh.getRow(row);
			XSSFCell c = r.getCell(col);
			
			s=c.getStringCellValue();
	}
		
				catch(IOException e)
		{
			
		 e.printStackTrace();
		}
		return(s);
	}
	
}