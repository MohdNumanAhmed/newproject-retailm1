package admin;

import org.openqa.selenium.WebDriver;

public class User_login {
	
	
	public static void main(String args[])
	{
        WebDriver dr = null;
        String kw,loc,td;
       
        Functions f =new Functions(dr);
        Read_excl excl = new Read_excl();
        
     	/*kw= excl.read(0,0);
     	System.out.println(kw);*/
     	
        
         for(int r=2;r<=6;r++)
         {
         	kw= excl.read(r, 2);
         	loc= excl.read(r, 3);
         	td= excl.read(r, 4);
         	
         	switch(kw)
         	{
         	case "launchchrome":
         		f.launchChrome(td);
         		break;
         	case "enter_txt":
         		f.enter_txt(loc, td);
         		break;
         	case "click_btn":
         		f.clik(loc);
         		break;
         	case "verify":
         		f.verify(loc,td);
         		break;
         	}
         }
       
	}

 }
       
